<?php

	$link = mysqli_connect("localhost","cl59-example-bui","yYj.3mj6V","cl59-example-bui");

?>